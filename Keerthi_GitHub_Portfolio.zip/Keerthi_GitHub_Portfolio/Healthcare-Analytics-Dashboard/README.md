# Healthcare Analytics Dashboard

## Project Overview
This project analyzes healthcare operational data to monitor patient volume, no-show rates, appointment utilization, wait times, and 30-day readmission trends.

## Business Problem
Healthcare leaders need a reliable way to track operational KPIs across departments and identify areas where patient access and resource utilization can improve.

## Tools Used
SQL, Power BI, Excel, Data Modeling, KPI Reporting

## Key KPIs
- Total appointments
- No-show rate
- Average wait time
- Readmission rate
- Department-level patient volume
- Insurance mix

## Folder Structure
```text
data/healthcare_sample_data.csv
sql/healthcare_kpi_queries.sql
powerbi/dashboard_requirements.md
images/dashboard_mockup_notes.md
```

## How to Use
1. Load the CSV file into Power BI or SQL.
2. Use the SQL queries to calculate KPIs.
3. Build visuals using the dashboard requirements document.
