import pandas as pd
from pathlib import Path

RAW_FILE = Path("../data/raw_healthcare_data.csv")
OUTPUT_FILE = Path("../output/clean_healthcare_data.csv")

def extract(file_path):
    return pd.read_csv(file_path)

def transform(df):
    df = df.copy()
    df.columns = [col.strip().lower() for col in df.columns]
    df["appointment_date"] = pd.to_datetime(df["appointment_date"])
    df["wait_time_minutes"] = df["wait_time_minutes"].clip(lower=0)
    return df.drop_duplicates()

def validate(df):
    required_columns = ["patient_id", "department", "appointment_status", "appointment_date"]
    missing = [col for col in required_columns if col not in df.columns]
    if missing:
        raise ValueError(f"Missing required columns: {missing}")
    return True

def load(df, output_file):
    output_file.parent.mkdir(parents=True, exist_ok=True)
    df.to_csv(output_file, index=False)

df = extract(RAW_FILE)
clean_df = transform(df)
validate(clean_df)
load(clean_df, OUTPUT_FILE)
print(f"ETL pipeline completed. Rows processed: {len(clean_df)}")
