# Sales Analytics Dashboard

## Project Overview
This project analyzes sales, customer segment, region, and campaign data to support executive reporting.

## Tools Used
SQL, Power BI, Excel, DAX

## KPIs
- Total revenue
- Average order value
- Sales by region
- Sales by product category
- Campaign performance
- Monthly revenue trend
