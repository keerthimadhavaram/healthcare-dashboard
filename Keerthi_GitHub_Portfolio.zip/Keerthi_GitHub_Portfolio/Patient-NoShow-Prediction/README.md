# Patient No-Show Prediction

## Project Overview
This project uses Python and machine learning to predict whether a patient is likely to miss an appointment.

## Business Problem
Patient no-shows reduce provider productivity, delay care, and create scheduling inefficiencies. Predicting no-shows helps healthcare teams take proactive action.

## Tools Used
Python, Pandas, NumPy, Scikit-learn, Random Forest

## Workflow
1. Load appointment data
2. Clean and encode categorical variables
3. Split training and testing data
4. Train classification model
5. Evaluate accuracy, precision, recall, and F1-score
