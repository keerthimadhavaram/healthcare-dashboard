-- Total Appointments
SELECT COUNT(*) AS total_appointments FROM healthcare_sample_data;

-- Appointment Status Breakdown
SELECT appointment_status, COUNT(*) AS appointment_count
FROM healthcare_sample_data
GROUP BY appointment_status
ORDER BY appointment_count DESC;

-- No-Show Rate
SELECT ROUND(100.0 * SUM(CASE WHEN appointment_status = 'No-Show' THEN 1 ELSE 0 END) / COUNT(*), 2) AS no_show_rate
FROM healthcare_sample_data;

-- Average Wait Time by Department
SELECT department, ROUND(AVG(wait_time_minutes), 2) AS avg_wait_time
FROM healthcare_sample_data
GROUP BY department
ORDER BY avg_wait_time DESC;

-- 30-Day Readmission Rate by Department
SELECT department, ROUND(100.0 * SUM(readmitted_30_days) / COUNT(*), 2) AS readmission_rate
FROM healthcare_sample_data
GROUP BY department
ORDER BY readmission_rate DESC;
