# Python Data Analysis

## Project Overview
This project performs exploratory data analysis on healthcare appointment data.

## Tools Used
Python, Pandas, NumPy, Matplotlib

## Analysis Performed
- Data cleaning
- Summary statistics
- Appointment status breakdown
- Department-level trends
- Wait time analysis
