import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import OneHotEncoder
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.metrics import classification_report, accuracy_score
from sklearn.ensemble import RandomForestClassifier

df = pd.read_csv("../data/healthcare_sample_data.csv")
df["target_no_show"] = (df["appointment_status"] == "No-Show").astype(int)

features = ["age", "gender", "department", "insurance_type", "wait_time_minutes"]
X = df[features]
y = df["target_no_show"]

preprocessor = ColumnTransformer([
    ("cat", OneHotEncoder(handle_unknown="ignore"), ["gender", "department", "insurance_type"]),
    ("num", "passthrough", ["age", "wait_time_minutes"])
])

model = Pipeline([
    ("preprocessor", preprocessor),
    ("classifier", RandomForestClassifier(n_estimators=100, random_state=42))
])

X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42, stratify=y)
model.fit(X_train, y_train)
predictions = model.predict(X_test)

print("Accuracy:", round(accuracy_score(y_test, predictions), 4))
print(classification_report(y_test, predictions))
