SELECT appointment_date,
       COUNT(*) AS daily_appointments,
       SUM(COUNT(*)) OVER (ORDER BY appointment_date) AS running_total
FROM healthcare_sample_data
GROUP BY appointment_date
ORDER BY appointment_date;
