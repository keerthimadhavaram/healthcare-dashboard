# ETL Pipeline Automation

## Project Overview
This project demonstrates a simple ETL workflow using Python.

## Workflow
1. Extract CSV data
2. Clean and transform fields
3. Validate data quality
4. Load processed data into an output folder

## Business Value
Automated ETL pipelines improve consistency, reduce manual effort, and provide reliable data for dashboards.
