import pandas as pd

df = pd.read_csv("../data/healthcare_sample_data.csv")

checks = {
    "total_rows": len(df),
    "missing_patient_id": int(df["patient_id"].isna().sum()),
    "missing_department": int(df["department"].isna().sum()),
    "duplicate_rows": int(df.duplicated().sum()),
    "negative_wait_times": int((df["wait_time_minutes"] < 0).sum()),
    "unexpected_status_count": int((~df["appointment_status"].isin(["Completed", "No-Show", "Cancelled"])).sum())
}

for check, value in checks.items():
    print(f"{check}: {value}")
