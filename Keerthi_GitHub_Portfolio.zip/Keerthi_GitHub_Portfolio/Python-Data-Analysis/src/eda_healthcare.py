import pandas as pd
import matplotlib.pyplot as plt

df = pd.read_csv("../data/healthcare_sample_data.csv")

print("Dataset Shape:", df.shape)
print(df.head())
print(df.describe())

status_counts = df["appointment_status"].value_counts()
print("\nAppointment Status Breakdown:")
print(status_counts)

department_wait = df.groupby("department")["wait_time_minutes"].mean().sort_values(ascending=False)
print("\nAverage Wait Time by Department:")
print(department_wait)

status_counts.plot(kind="bar", title="Appointment Status Breakdown")
plt.xlabel("Status")
plt.ylabel("Count")
plt.tight_layout()
plt.savefig("../images/appointment_status_breakdown.png")
