# Data Quality Validation Framework

## Project Overview
This project validates healthcare data before it is used for reporting and dashboards.

## Validation Checks
- Missing values
- Duplicate records
- Invalid ranges
- Unexpected categories
- Date format issues

## Business Value
Data quality checks improve dashboard accuracy, reduce reporting errors, and increase stakeholder trust.
