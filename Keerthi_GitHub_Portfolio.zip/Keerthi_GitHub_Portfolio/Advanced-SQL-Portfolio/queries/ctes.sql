WITH department_summary AS (
    SELECT department,
           COUNT(*) AS total_appointments,
           SUM(CASE WHEN appointment_status = 'No-Show' THEN 1 ELSE 0 END) AS no_show_count
    FROM healthcare_sample_data
    GROUP BY department
)
SELECT department, total_appointments, no_show_count,
       ROUND(100.0 * no_show_count / total_appointments, 2) AS no_show_rate
FROM department_summary
ORDER BY no_show_rate DESC;
