SELECT SUM(sales_amount) AS total_revenue FROM sales_sample_data;

SELECT region, SUM(sales_amount) AS revenue
FROM sales_sample_data
GROUP BY region
ORDER BY revenue DESC;

SELECT product_category, SUM(sales_amount) AS revenue
FROM sales_sample_data
GROUP BY product_category
ORDER BY revenue DESC;

SELECT campaign, COUNT(*) AS order_count, SUM(sales_amount) AS revenue
FROM sales_sample_data
GROUP BY campaign
ORDER BY revenue DESC;
