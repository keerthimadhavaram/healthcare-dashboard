SELECT COUNT(*) AS missing_department_count
FROM healthcare_sample_data
WHERE department IS NULL OR department = '';

SELECT patient_id, appointment_date, department, COUNT(*) AS duplicate_count
FROM healthcare_sample_data
GROUP BY patient_id, appointment_date, department
HAVING COUNT(*) > 1;
