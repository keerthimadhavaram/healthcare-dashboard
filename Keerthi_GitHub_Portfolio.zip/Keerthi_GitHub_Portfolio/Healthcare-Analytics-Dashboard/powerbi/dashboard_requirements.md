# Power BI Dashboard Requirements

## Dashboard Pages
1. Executive Summary
2. Department Performance
3. Patient Access & No-Show Analysis
4. Readmission and Wait Time Trends

## Recommended Visuals
- KPI Cards: Total Appointments, No-Show Rate, Avg Wait Time, Readmission Rate
- Line Chart: Monthly Appointment Trend
- Bar Chart: Department Patient Volume
- Donut Chart: Appointment Status Breakdown
- Matrix: Department vs Insurance Type
- Slicers: Date, Department, Insurance Type, Gender

## DAX Measures
```DAX
Total Appointments = COUNTROWS(Healthcare)
No Show Count = CALCULATE(COUNTROWS(Healthcare), Healthcare[appointment_status] = "No-Show")
No Show Rate = DIVIDE([No Show Count], [Total Appointments])
Average Wait Time = AVERAGE(Healthcare[wait_time_minutes])
Readmission Rate = DIVIDE(SUM(Healthcare[readmitted_30_days]), [Total Appointments])
```
