# Advanced SQL Portfolio

## Overview
This repository contains practical SQL examples commonly used in Data Analyst and BI Analyst roles.

## Topics Covered
- Joins
- CTEs
- Window Functions
- Subqueries
- KPI Calculations
- Data Quality Checks
